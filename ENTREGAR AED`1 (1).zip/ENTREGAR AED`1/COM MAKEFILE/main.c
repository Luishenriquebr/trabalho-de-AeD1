#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "poketrunfo.h"

#define NAMES 50
#define MAX 50
#define NUM_VALORES 10

int main() {
    // variáveis
    Lista2* lista = NULL;
    Fila* fila = cria_fila();
    int valores [NUM_VALORES];
    Fila* filajog1 = cria_fila();
    Fila* filajog2 = cria_fila();
    Pilha* pilha = cria_pilha();
    int telaload = 0;
    // abre o arquivo e preenche a lista
    lista = openarq(); 
    // inserindo os pokemons para a fila
    EmbaralhaEInsere(lista, pilha, valores);
    // transferindo para as filas dos jogadores
    transferePilhaParaFilas(pilha, filajog1, filajog2);

        printf("\n===================================================\n");
        printf("\t BEM VINDO(A) AO POKETRUNFO DUSGURI");
        printf("\n===================================================\n");

    while (telaload != 10) {
        printf("\n");
        printf("\t ESCOLHA UMA ALTERNATIVA!!\n\n");
        printf("\t INICIAR JOGO (0)\n");
        printf("\t CONSULTA POKEDEX (1)\n");
        printf("\t SAIR DO JOGO (10)\n");
        scanf("%d", &telaload);

        switch (telaload) {
            case 0:
                batalhaaaaa(filajog1, filajog2);
                break;

            case 1:
                busca_pokedex(lista);
                break;

            case 2:
                printf ("NAO TEM NADA AQUI!!!!!");
                exit (0);
                break;

                case 10:
                exit (0);
                break;

            default:
                printf("Digita outro numero guri!!!\n");
                break;
        }
    }
 

    // liberar_lista(lista);
    libera_fila(fila);
    libera_fila(filajog1);
    libera_fila(filajog2);

    return 0;
}

